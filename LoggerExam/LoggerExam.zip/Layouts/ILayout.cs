﻿namespace LoggerExam.Layouts
{
    public interface ILayout
    {
        string Format { get; }
    }
}