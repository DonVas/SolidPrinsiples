﻿namespace LoggerExam.Core
{
    public interface IEngine
    {
        void Run();
    }
}